<?php
require_once('Controller.php');
require_once(__DIR__ .'/../models/User.php');

class UserController extends Controller
{  
    public function index()
    {
        $users = User::all();
        
        return $users;
    
    }

    public function show($id)
    {
        $user = User::find($id);
        
        return $user;
    
    }

    public function store($array)
    {
        $users = User::store($array);
        
        return 'You Have Been Registered';
    
    }

    public function edit($id)
    {
        $this->viewWith('user_edit', $id);
    }

    public function update($array, $id)
    {
        $user = User::update($array, $id);
        if($user)
            return "User Successfully Updated!!!";
    }

    public function destroy($id)
    {
        User::destroy($id);

        $this->view('user_index');
    }
}
