<?php
session_start();
require_once 'Controller.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Admin.php';
require_once __DIR__ . '/../models/Employee.php';

class LoginController extends Controller
{
    public function validate($username, $password, $utype)
    {
        $username = trim($username);
        $password = trim($password);
        
        $flag = false;
        if ($utype == 'user') {
            $users = User::all();

            for ($i = 0; $i < count($users); $i++) {
                if ($users[$i]->username == $username && $users[$i]->password == $password) {
                    $flag = true;
                    break;
                }
            }
        } else if ($utype == 'employee') {
            $employee = Employee::all();

            for ($i = 0; $i < count($employee); $i++) {
                if ($employee[$i]->username == $username && $employee[$i]->password == $password) {
                    $flag = true;
                    break;
                }
            }
        } else if ($utype == 'admin') {
            $admins = Admin::all();
            //print_r ($admins);

            for ($i = 0; $i < count($admins); $i++) {
                if ($admins[$i]->username == $username && $admins[$i]->password == $password) {
                    $flag = true;
                    break;
                }
            }
        }

        if (!$flag) {
            return 'username and password does not match';
        } else {
            if($utype == 'admin')
            {
                $_SESSION["username"] = $username;
                $_SESSION["utype"] = 'admin';
                $this->view('views/admin_home');
            }
            else if($utype == 'user')
            {
                $_SESSION["username"] = $username;
                $_SESSION["utype"] = 'user';
                $this->view('views/user_home');
            }
            else if($utype == 'employee')
            {
                $_SESSION["username"] = $username;
                $_SESSION["utype"] = 'employee';
                $this->view('views/employee_home');
            }
        }

        //$user->find(1)
        //var_dump($user);
        //$this->view('home');
    }
}
