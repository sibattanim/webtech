<?php
require_once('Controller.php');
require_once(__DIR__ .'/../models/Admin.php');

class AdminController extends Controller
{
    public function create($array)
    {
        $users = User::create($array);
        
        return 'You Have Been Registered';
    
    }
}
