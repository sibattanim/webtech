<?php
require_once('Controller.php');
require_once(__DIR__ .'/../models/Employee.php');

class EmployeeController extends Controller
{  
    public function index()
    {
        $users = Employee::all();
        
        return $users;
    
    }

    public function show($id)
    {
        $user = Employee::find($id);
        
        return $user;
    
    }

    public function store($array)
    {
        $users = Employee::store($array);
        
        return 'Employee Have Been Created';
    
    }

    public function edit($id)
    {
        $this->viewWith('staff_edit', $id);
    }

    public function update($array, $id)
    {
        $user = Employee::update($array, $id);
        if($user)
            return "Employee Successfully Updated!!!";
    }

    public function destroy($id)
    {
        Employee::destroy($id);

        $this->view('staff_index');
    }
}
