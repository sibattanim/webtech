<?php
 
class Controller
{
    function __construct()
    {
        
    }

    function view($view)
    {
        header("Location: $view.php");
    }

    function viewWith($view, $with)
    {
        header("Location: $view.php?id=$with");
    }
}
