<?php
require_once('Controller.php');
require_once(__DIR__ .'/../models/Booking.php');

class BookingController extends Controller
{  
    public function index()
    {
        $Bookings = Booking::all();
        
        return $Bookings;  
    }


    public function store($array)
    {
        $Bookings = Booking::store($array);
        
        return 'Booking Have Been Created';
    }

    public function update($array, $id)
    {
        $booking = Booking::update($array, $id);
        if($booking)
            return "Booking Successfully Updated!!!";
    }

    public function findByUsername($username)
    {
        $Bookings = Booking::raw("SELECT * FROM bookings where username = '$username' ");

        return $Bookings;
    }

    public function findByStatus($status)
    {
        $Bookings = Booking::raw("SELECT * FROM bookings WHERE status = '$status' ");

        return $Bookings;
    }

    
    
}
