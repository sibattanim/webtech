<?php
require_once 'Model.php';

class Admin extends Model
{
    protected static $table_name = "admins";
}
