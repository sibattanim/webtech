<?php
require_once 'Model.php';

class Order extends Model
{
    protected static $table_name = "orders";
}
