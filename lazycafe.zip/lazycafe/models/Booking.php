<?php
require_once 'Model.php';

class Booking extends Model
{
    protected static $table_name = "bookings";
}
