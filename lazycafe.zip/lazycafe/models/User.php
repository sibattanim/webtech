<?php
require_once 'Model.php';

class User extends Model
{
    protected static $table_name = "users";
}
