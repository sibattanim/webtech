<?php

require_once 'controllers/LoginController.php';

$err_uname = '';
$err_pass = '';
$err_invalid = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['username'];
    $password = $_POST['password'];
    $utype = $_POST['utype'];

    $flag = true;

    if (empty($username)) {
        $err_uname = "*username is required";
        $flag = false;
    }

    if (empty($password)) {
        $err_pass = "*password is required";
        $flag = false;
    }

    if ($flag) {
        $login = new LoginController;
        $log = $login->validate($username, $password, $utype);
        
        $err_invalid = $log;
        
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index Page</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-primary">
            <ul class="nav-item">
                <li><a href="">Home</a></li>
                <li><a href="views/about.php">About Us</a></li>
                <li><a href="views/registration.php">Registration</a></li>
                <li><a href="views/feedback.php">Feedback</a></li>
                <li><a href="views/contact.php">Contact Us</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-3">

            <fieldset>
                <legend>Login</legend>
                <form method="post" action="">
                    <br>
                    <label for="utype">User Type</label>
                    <select id="utype" name="utype">
                        <option value="user">User</option>
                        <option value="employee">Employee</option>
                        <option value="admin">Admin</option>
                    </select><br>
                    <small class="text-danger"> <?=$err_invalid?> </small><br><br>
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username"><br>
                    <small class="text-danger"> <?=$err_uname?> </small><br><br>

                    <label for="password">Password</label>
                    <input type="password" id="password" name="password"><br>
                    <small class="text-danger"> <?=$err_pass?> </small><br><br>

                    <input class="btn btn-primary" type="submit" value="Login">
                </form>
            </fieldset>

        </div>
        <div class="col-6">
            <h2 class="text-center">Welcome To Our Cafe</h2>
            <p>
            As far back as I can remember, I have always liked going out to eat. Two of my favorite restaurants are Jake’s and McDonald’s.
		    Though both are places to dine they have their differences in their ambiance, waiting, and expense. When deciding where to go to eat,
		    I have three things to think about. I must consider the atmosphere or where I want to go. The amount of time I have is another consideration.
		    The amount of money that I am able to spend is a big influence.The atmosphere at Jake’s is casual, and people came to spend several hours.
		    Jake’s has a waiting room with long, leather-topped benches to sit on while waiting. Some tables are round and some are long rectangles,
		    so everything can fit on them.
            </p>

            <p>
            The customer ordering website or app will generally have several key requirements to function adequately. These requirements are:

            <br>1. Accessible across all devices from tablets to PCs.

            <br>2. Easily search the restaurant's menu and see what is available

            <br>3. Configure their order type such as delivery or pickup

            <br>4. Choose when they would like to receive the order

            <br>5. Make online payments via credit card, bank transfer, etc.

            <br>6. Stay up to date on the status of the orders they have placed

            <br>7. View all their past orders and quickly re-order their favourite items
            </p>
        </div>
    </div>

    <footer class="footer-fixed">
        <p>Footer</p>
    </footer>
</body>

</html>