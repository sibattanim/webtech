<?php

require_once __DIR__ . '/../controllers/UserController.php';

$errs = [];
$username = $password = $name = $contact = $email = $address = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['username'];
    $password = $_POST['password'];
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    if (empty($username)) {
        $errs[] = "*username is required";
    }

    if (empty($password)) {
        $errs[] = "*password is required";
    }

    if (empty($name)) {
        $errs[] = "*name is required";
    }

    if (empty($contact)) {
        $errs[] = "*contact is required";
    }

    if (empty($email)) {
        $errs[] = "*email is required";
    }

    if (empty($address)) {
        $errs[] = "*address is required";
    }

    if (count($errs) == 0) {
        $User = new UserController;
        $datas = [
            'username' => $username,
            'password' => $password,
            'name' => $name,
            'gender' => $gender,
            'contact' => $contact,
            'email' => $email,
            'address' => $address
        ];
        $flag = $User->store($datas);

        $username = $password = $name = $contact = $email = $address = '';
        $success = $flag;

    }

}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-primary">
            <ul class="nav-item">
                <li><a href="../index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="registration.php">Registration</a></li>
                <li><a href="feedback.php">Feedback</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-3"></div>
        <div class="col-4">

            <fieldset>
                <legend>Registration Form</legend>

                <form method="post" action="">

                    <?php if (!empty($success)) {?>
                    <div class="alert alert-success">
                        <?=$success?> <br>
                    </div>
                    <?php }?>

                    <?php if (count($errs) > 0) {?>
                    <div class="alert alert-danger">
                        <?php foreach ($errs as $err) {?>
                        <?=$err?> <br>
                        <?php }?>
                    </div>
                    <?php }?>

                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" value="<?=$username?>"><br>


                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" value="<?=$password?>"><br>


                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" value="<?=$name?>"><br>


                    <label for="gender">Gender</label>
                    <select id="gender" name="gender">
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select><br>

                    <label for="contact">Contact</label>
                    <input type="number" id="contact" name="contact" value="<?=$contact?>"><br>

                    <label for="contact">Email</label>
                    <input type="email" id="email" name="email" value="<?=$email?>"><br>


                    <label for="address">Address</label>
                    <textarea id="address" name="address" rows="4" cols="50"> <?=$address?> </textarea>


                    <input class="btn btn-primary" type="submit" value="Register">
                </form>
            </fieldset>

        </div>
        <div class="col-3"></div>

    </div>

    <footer class="footer">
        <p>Footer</p>
    </footer>
</body>

</html>