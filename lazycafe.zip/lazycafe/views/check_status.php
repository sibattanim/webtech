<?php
session_start();

if (!isset($_SESSION["utype"]) or $_SESSION["utype"] != 'user') {
    header("Location: ../index.php");
}

require_once __DIR__ . '/../controllers/BookingController.php';

$bookingController = new BookingController;
$bookings = $bookingController->findByUsername($_SESSION["username"]);

?>

<!DOCTYPE html>
<html>

<head>
    <meta date="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Status</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-primary">
            <ul class="nav-item">
                <li><a href="booking_home.php">Home</a></li>
                <li><a href="booking_menu.php">Menu</a></li>
                <li><a href="online_booking.php">Online Booking</a></li>
                <li><a href="check_status.php">Check Status</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-2"></div>
        <div class="col-5 text-center">
           
            <h1 class="text-secondary">bookings</h1>
    
            <table>
                <tr>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Table No</th>
                    <th>Seats</th>
                    <th>Status</th>
                </tr>
                <?php

                    if($bookings)
                    {
                        foreach ($bookings as $booking) {
                            echo "<tr> ";
                            echo "<td>$booking->date</td>";
                            echo "<td>$booking->time_from to $booking->time_to</td>";
                            echo "<td>$booking->table_no</td>";
                            echo "<td>$booking->seats</td>";
                            echo "<td>$booking->status</td>";
                            echo "</tr>";
                        }
                    }
           
                ?>
            </table>
        </div>
        <div class="col-2"></div>
    </div>

    <div class="footer-space"></div>
    <footer class="footer-fixed bg-primary">
        <p>Footer</p>
    </footer>

    <script>
    document.getElementById('date').valueAsDate = new Date();
    </script>
</body>

</html>