<?php
session_start();

if (!isset($_SESSION["utype"]) or $_SESSION["utype"] != 'admin') {
    header("Location: ../index.php");
}

require_once __DIR__ . '/../controllers/ProductController.php';

$productController = new ProductController;
$products = $productController->index();

if(isset($_GET['productid']))
{
   if($_GET['method'] == 'edit')
   {
        $productController->edit($_GET['productid']);
   }
   else if($_GET['method'] == 'delete')
   {
        $productController->destroy($_GET['productid']);
   }  
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Index</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="../assets/css/style.css"></script>
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>

</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-admin">
            <ul class="nav-item">
                <li><a href="admin_home.php">Home</a></li>
                <li><a href="product_index.php">User Panel</a></li>
                <li><a href="staff_index.php">Staff Panel</a></li>
                <li><a href="product_index.php">Product Panel</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-2"></div>
        <div class="col-5 text-center">
           
            <h1 class="text-secondary">Products</h1>
            <a href="product_create.php" class="btn btn-primary">Create New product</a> <br> <br>
            <table>
                <tr>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
                <?php

                    if($products)
                    {
                        foreach ($products as $product) {
                            echo "<tr> ";
                            echo "<td>$product->name</td>";
                            echo "<td>$product->category</td>";
                            echo "<td>$product->price</td>";
                            echo "<td><img width= '100px' height='100px' src='$product->image_path' alt='image'></td>"; 
                            
                            echo "<td>";
                            echo "<button class='btn btn-success' onclick='productEdit($product->id)'>Edit</button>";
                            echo "<button class='btn btn-danger' onclick='productDelete($product->id)'>Delete</button>";         
                            echo "</td>"; 
                            echo "</tr>";
                        }
                    }
           
                ?>
            </table>
        </div>
        <div class="col-2"></div>
    </div>
    
    <div class="footer-space"></div>
    <footer class="footer-fixed bg-admin">
        <p>Footer</p>
    </footer>
    <script>
    function productDelete(id) {
        var r = confirm("Are You Sure Your Want to Delete This product?");
        if (r == true) {
            window.location.href = `product_index.php?productid=${id}&method=delete`;
        } 
    }

    function productEdit(id) {
        window.location.href = `product_index.php?productid=${id}&method=edit`;
    }
    </script>
</body>

</html>