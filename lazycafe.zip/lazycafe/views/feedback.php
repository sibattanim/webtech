<?php


require_once __DIR__ . '/../controllers/FeedbackController.php';

$errs = [];
$name = $contact = $email = $message = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    if (empty($name)) {
        $errs[] = "*Name is required";
    }

    if (empty($contact)) {
        $errs[] = "*Contact is required";
    }

    if (empty($email)) {
        $errs[] = "*Email is required";
    }

    if (empty($message)) {
        $errs[] = "*Message is required";
    }

    if (count($errs) == 0) {
        $feedback = new FeedbackController;
        $datas = [
            'name' => $name,
            'contact' => $contact,
            'email' => $email,
            'message' => $message
        ];
        $flag = $feedback->create($datas);

        $name = $contact = $email = $message = '';
        $success = $flag;

    }

}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index Page</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-primary">
            <ul class="nav-item">
                <li><a href="../index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="registration.php">Registration</a></li>
                <li><a href="feedback.php">Feedback</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-1"></div>
        <div class="col-3">
            <br><br><br><br><br>
            <h1 class="text-center text-danger">PLEASE SEND YOUR FEEDBACK</h1>
            <h2 class="text-center">QUERIES AND VIEW</h2>
        </div>

        <div class="col-3">
            <fieldset>
                <legend>Feedbacks</legend>
                <form method="post" action="">

                    <?php if (!empty($success)) {?>
                    <div class="alert alert-success">
                        <?=$success?> <br>
                    </div>
                    <?php }?>

                    <?php if (count($errs) > 0) {?>
                    <div class="alert alert-danger">
                        <?php foreach ($errs as $err) {?>
                        <?=$err?> <br>
                        <?php }?>
                    </div>
                    <?php }?>

                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" value="<?=$name?>"><br>

                    <label for="contact">Contact</label>
                    <input type="number" id="contact" name="contact" value="<?=$contact?>"><br>

                    <label for="contact">Email</label>
                    <input type="email" id="email" name="email" value="<?=$email?>"><br>

                    <label for="message">Message/Query</label>
                    <textarea id="message" name="message" rows="4" cols="50"> <?=$message?> </textarea>
                    <input class="btn btn-primary" type="submit" value="Submit">
                </form>
            </fieldset>
        </div>
        <div class="col-1"></div>
    </div>

    
</body>

</html>