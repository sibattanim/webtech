<?php
session_start();

if (!isset($_SESSION["utype"]) or $_SESSION["utype"] != 'user') {
    header("Location: ../index.php");
}

require_once __DIR__ . '/../controllers/ProductController.php';

$productController = new ProductController;
$categories = $productController->getCategories();

if(isset($_GET['category']))
{
    $products = '';
    if($_GET['category'] == 'none')
    {
        $products = $productController->index();
    }else{
        $products = $productController->getProductListByCategory($_GET['category']);
    }
    
    
    $html = '';
    foreach ($products as $product) {
        $html .= "<tr>";
        $html .= "<td>$product->name</td>";
        $html .= "<td>$product->price";
        $html .= "<td> <img width='100px' height='100px' src='$product->image_path' alt='$product->name'> </td>"; 
        $html .= "<td>$product->description</td>";
        $html .= "</tr>";
    }
    echo $html;
    return;
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-primary">
            <ul class="nav-item">
                <li><a href="user_home.php">Home</a></li>
                <li><a href="user_menu.php">Menu</a></li>
                <li><a href="online_booking.php">Online Booking</a></li>
                <li><a href="check_status.php">Check Status</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-2"></div>
        <div class="col-4 text-center">

            <h1 class="text-secondary">Menus</h1>
            <select onchange="getMenuList()" class="select-50" id="category" name="category">
                <option value="none">Select a category</option>
                <?php 
                    foreach ($categories as $categorie) {
                       echo "<option value='$categorie->category'>$categorie->category</option>";
                    }
                ?>
            </select><br><br>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody id="tbody">

                </tbody>
            </table>
        </div>
        <div class="col-2"></div>
    </div>

    <div class="footer-space"></div>
    <footer class="footer-fixed bg-primary">
        <p>Footer</p>
    </footer>

    <script>
    ajaxFunction('none')

    function getMenuList() {
        var e = document.getElementById("category");
        var selected = e.options[e.selectedIndex].value;
        ajaxFunction(selected)
    }

    function ajaxFunction(selected) {

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                console.log(this.responseText)
                document.getElementById("tbody").innerHTML =
                    this.responseText;
            }
        };
        xhttp.open("GET", `user_menu.php?category=${selected}`, true);
        xhttp.send();

    }
    </script>
</body>

</html>