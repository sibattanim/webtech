<?php
session_start();

if (!isset($_SESSION["utype"]) or $_SESSION["utype"] != 'employee') {
    header("Location: ../index.php");
}

$product = $qunatity = $total = '';
if(isset($_GET['name']))
{
   $name =  $_GET['name'];
   $product =  $_GET['product'];
   $unit_price = $_GET['price'];
   $qunatity = $_GET['quantity'];
   $total = $unit_price * $qunatity;
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Bill</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-employee">
            <ul class="nav-item">
                <li><a href="employee_home.php">Home</a></li>
                <li><a href="billing.php">Billing</a></li>
                <li><a href="verify_booking.php">Verify Booking</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container text-center text-secondary">
        <div class="col-2"></div>
        <div class="col-2">
        <fieldset>
            <legend>Bill</legend>
            <h2>Name:- <?=$name?></h2>
            <h3>Product:- <?=$product?></h3>
            <h3>Quantity:- <?=$qunatity?></h3>
            <h3>Unit Price:- <?=$unit_price?></h3>
            <h3>Total Price:- <?=$total?></h3>
        </fieldset>
        </div>
        <div class="col-2"></div>
    </div>

    <div class="footer-space"></div>
    <footer class="footer-fixed bg-employee">
        <p>Footer</p>
    </footer>
</body>

</html>