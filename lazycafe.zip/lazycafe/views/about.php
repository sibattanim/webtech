<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index Page</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-primary">
            <ul class="nav-item">
                <li><a href="../index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="registration.php">Registration</a></li>
                <li><a href="feedback.php">Feedback</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-3"></div>
        <div class="col-4 text-center">
            <fieldset>
                <legend>About Us</legend>
                <!-- Type here -->
                <p> As far back as I can remember, I have always liked going out to eat. Two of my favorite restaurants are Jake’s and McDonald’s. Though both are places to dine they have their differences in their ambiance, waiting, and expense. When deciding where to go to eat, I have three things to think about. I must consider the atmosphere or where I want to go. The amount of time I have is another consideration. The amount of money that I am able to spend is a big influence.The atmosphere at Jake’s is casual, and people came to spend several hours. Jake’s has a waiting room with long, leather-topped benches to sit on while waiting. Some tables are round and some are long rectangles, so everything can fit on them.</p>
            </fieldset>
        </div>
        <div class="col-3"></div>
    </div>


    
</body>

</html>