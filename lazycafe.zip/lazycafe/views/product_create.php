<?php
session_start();

if (!isset($_SESSION["utype"]) or $_SESSION["utype"] != 'admin') {
    header("Location: ../index.php");
}
require_once __DIR__ . '/../controllers/ProductController.php';

$errs = [];
$name = $category = $description = $price = $image_path = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $description = trim($_POST['description']);
    $category = $_POST['category'];
    $price = $_POST['price'];
    $image_path = $_FILES['image_path']["name"];

    if (empty($name)) {
        $errs[] = "*Name is required";
    }

    if (empty($category)) {
        $errs[] = "*Category is required";
    }

    if (empty($price)) {
        $errs[] = "*Price is required";
    }

    if (empty($description)) {
        $errs[] = "*Description is required";
    }

    if (empty($image_path)) {
        $errs[] = "*Image is required";
    }

    if (count($errs) == 0) {

        $target_dir = "../assets/uploads/";
        $target_file = $target_dir . basename($_FILES["image_path"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if image file is a actual image or fake image
        $check = getimagesize($_FILES["image_path"]["tmp_name"]);
        if ($check !== false) {
            //$errs[] = "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            $errs[] = "File is not an image.";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            $errs[] = "Sorry, your file was not uploaded.";
            // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES["image_path"]["tmp_name"], $target_file)) {

            } else {
                $errs[] =  "Sorry, there was an error uploading your file.";
            }
        }

        if ($uploadOk == 1) {
            $User = new ProductController;
            $datas = [
                'name' => $name,
                'description' => $description,
                'category' => $category,
                'price' => $price,
                'image_path' => $target_file,
            ];
            $flag = $User->store($datas);

            $name = $category = $price = $description = '';
            $success = $flag;
        }

    }

}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Create Page</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-admin">
            <ul class="nav-item">
                <li><a href="admin_home.php">Home</a></li>
                <li><a href="user_index.php">User Panel</a></li>
                <li><a href="staff_index.php">Staff Panel</a></li>
                <li><a href="product_index.php">Product Panel</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-3"></div>
        <div class="col-4">

            <fieldset>
                <legend>Product Create</legend>

                <form method="post" action="" enctype="multipart/form-data">

                    <?php if (!empty($success)) {?>
                    <div class="alert alert-success">
                        <?=$success?> <br>
                    </div>
                    <?php }?>

                    <?php if (count($errs) > 0) {?>
                    <div class="alert alert-danger">
                        <?php foreach ($errs as $err) {?>
                        <?=$err?> <br>
                        <?php }?>
                    </div>
                    <?php }?>

                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" value="<?=$name?>"><br>

                    <label for="category">Category</label>
                    <select id="category" name="category">
                        <option value="chinese">Chinese</option>
                        <option value="thai">Thai</option>
                    </select><br>

                    <label for="price">Price</label>
                    <input type="text" id="price" name="price" value="<?=$price?>"><br>

                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="4" cols="50"><?=$description?></textarea> <br>

                    <label for="Image">Image</label> <br>
                    <input type="file" name="image_path" id="image_path"> <br> <br>

                    <input class="btn btn-primary" type="submit" value="Create">
                </form>
            </fieldset>

        </div>
        <div class="col-3"></div>

    </div>
    <div class="footer-space"></div>
    <footer class="bg-admin footer-fixed">
        <p>Footer</p>
    </footer>
</body>

</html>