<?php
session_start();

if (!isset($_SESSION["utype"]) or $_SESSION["utype"] != 'employee') {
    header("Location: ../index.php");
}



require_once __DIR__ . '/../controllers/ProductController.php';
require_once __DIR__ . '/../controllers/OrderController.php';

$productController = new ProductController;
$products = $productController->index();

$errs = [];
$name = $quantity = $product = '';
$success = '';
$order_info = '';
$flag = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $product = $_POST['product'];
    $quantity = $_POST['quantity'];
    $product = explode("/", $product);
    
    if (empty($name)) {
        $errs[] = "*name is required";
    }

    if (empty($quantity)) {
        $errs[] = "*quantity is required";
    }

    if (count($errs) == 0) {
        $order = new OrderController;
        $datas = [
            'name' => $name,
            'product' => $product[0],
            'quantity' => $quantity,
            'total_price' => $product[1] * $quantity,
        ];
        $flag = $order->store($datas);
        $product_name = $product[0];
        $unit_price = $product[1];
        $order_info = "name=$name&product=$product_name&quantity=$quantity&price=$unit_price";
        $name = $quantity = '';
        $success = $flag;

    }

}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Home</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-employee">
            <ul class="nav-item">
                <li><a href="employee_home.php">Home</a></li>
                <li><a href="billing.php">Billing</a></li>
                <li><a href="verify_booking.php">Verify Booking</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-3"></div>
        <div class="col-4">

            <fieldset>
                <legend>Create Order</legend>

                <form method="post" action="">

                    <?php if (!empty($success)) {?>
                    <div class="alert alert-success">
                        <?=$success?> <br>
                    </div>
                    <?php }?>

                    <?php if (count($errs) > 0) {?>
                    <div class="alert alert-danger">
                        <?php foreach ($errs as $err) {?>
                        <?=$err?> <br>
                        <?php }?>
                    </div>
                    <?php }?>

                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" value="<?=$name?>"><br><br>

                    <label for="product">Product</label>
                    <select id="product" name="product">
                    <?php 
                        foreach ($products as $product) {
                            echo "<option value='$product->name/$product->price'>$product->name</option>";
                        }
                    ?>   
                    </select><br><br>

                    <label for="quantity">quantity</label>
                    <input type="number" id="quantity" name="quantity" value="<?=$quantity?>"><br><br>

                    <input class="btn btn-primary" type="submit" value="Add Order">
                    <?php 
                        if(!empty($order_info))
                        {
                            echo "<a class='btn btn-success' href='generate_bill.php?$order_info'>Generate Bill</a>";
                        }
                    ?>
                </form>
            </fieldset>

        </div>
        <div class="col-3"></div>

    </div>

    <div class="footer-space"></div>
    <footer class="footer-fixed bg-employee">
        <p>Footer</p>
    </footer>
</body>

</html>