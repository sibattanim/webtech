<?php
session_start();

if (!isset($_SESSION["utype"]) or $_SESSION["utype"] != 'user') {
    header("Location: ../index.php");
}

require_once __DIR__ . '/../controllers/BookingController.php';

$errs = [];
$seats = $date = $time_from = $time_to = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $seats = $_POST['seats'];  
    $date = $_POST['date'];
    $table_no = $_POST['table_no'];
    $time_from = $_POST['time_from'];
    $time_to = $_POST['time_to'];

    if (empty($seats)) {
        $errs[] = "*seats is required";
    }

    if (empty($date)) {
        $errs[] = "*date is required";
    }

    if (empty($time_from) or empty($time_to)) {
        $errs[] = "*time is required";
    }

    if (count($errs) == 0) {
        $booking = new BookingController;
        $datas = [
            'username' => $_SESSION["username"],
            'seats' => $seats,     
            'date' => $date,
            'table_no' => $table_no,
            'time_from' => $time_from,      
            'time_to' => $time_to,      
        ];

        $flag = $booking->store($datas);

        $seats = $date = $time_from = $time_to = '';
        $success = $flag;

    }

}

?>

<!DOCTYPE html>
<html>

<head>
    <meta date="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Booking</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    legend {
        font-size: 40px;
    }

    fieldset {
        border-radius: 50px 15px;
    }
    </style>
</head>

<body>
    <div class="nav">
        <div class="col-3 text-center bg-primary">
            <ul class="nav-item">
                <li><a href="user_home.php">Home</a></li>
                <li><a href="user_menu.php">Menu</a></li>
                <li><a href="online_booking.php">Online Booking</a></li>
                <li><a href="check_status.php">Check Status</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>

    <div class="img-container">
        <img width="100%" height="250px" src="../assets/image/bg.jpg" alt="" />
        <div class="centered-text">Lazy Cafe</div>
    </div>

    <div class="container">
        <div class="col-3"></div>
        <div class="col-4">

            <fieldset>
                <legend>Book Table</legend>

                <form method="post" action="">

                    <?php if (!empty($success)) {?>
                    <div class="alert alert-success">
                        <?=$success?> <br>
                    </div>
                    <?php }?>

                    <?php if (count($errs) > 0) {?>
                    <div class="alert alert-danger">
                        <?php foreach ($errs as $err) {?>
                        <?=$err?> <br>
                        <?php }?>
                    </div>
                    <?php }?>

                    <label for="table_no">Select Table</label>
                    <select id="table_no" name="table_no">
                        <option value="table-1">Table-1</option>
                        <option value="table-2">Table-2</option>
                        <option value="table-3">Table-3</option>
                        <option value="table-4">Table-4</option>
                    </select><br>

                    <label for="seats">Seats</label>
                    <input type="number" id="seats" name="seats" value="<?=$seats?>"><br>

                    <label for="date">Booking Date</label>
                    <input type="date" id="date" name="date" value="<?=$date?>"><br>

                    <label for="time">Time</label>
                    <div class="container" style="margin:0px; padding:0px">
                        <select id="time_from" name="time_from">
                            <option>10</option>
                            <option>11</option>
                            <option>12</option>
                            <?php
                                for ($i=1; $i <= 7; $i++) { 
                                    echo "<option>$i</option>";
                                }
                            ?>
                        </select>
                        <label style="margin:13px" for="time">To</label>
                        <select id="time_to" name="time_to">
                            <option>10</option>
                            <option>11</option>
                            <option>12</option>
                            <?php
                                for ($i=1; $i <= 7; $i++) { 
                                    echo "<option>$i</option>";
                                }
                            ?>
                        </select>
                    </div><br>

                    <input class="btn btn-primary" type="submit" value="Book">
                </form>
            </fieldset>

        </div>
        <div class="col-3"></div>

    </div>

    <div class="footer-space"></div>
    <footer class="footer-fixed bg-primary">
        <p>Footer</p>
    </footer>

    <script>
    document.getElementById('date').valueAsDate = new Date();
    </script>
</body>

</html>